from django.contrib import admin
from.models import CreateStudyMaterialService, Notes

# Register your models here.

admin.site.register(CreateStudyMaterialService)
admin.site.register(Notes)
